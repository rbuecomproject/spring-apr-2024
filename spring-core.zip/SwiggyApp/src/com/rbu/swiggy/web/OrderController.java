package com.rbu.swiggy.web;

public class OrderController {
	
	public OrderController() {
		System.out.println("OrderController... object created");
	}

}
