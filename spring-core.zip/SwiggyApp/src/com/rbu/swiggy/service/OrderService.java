package com.rbu.swiggy.service;

public class OrderService {
	
	public OrderService() {
		System.out.println("OrderService... object created");
	}

}
