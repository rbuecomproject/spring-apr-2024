package com.rbu.swiggy.dao;

public class OrderServiceDao {
public OrderServiceDao() {
System.out.println("OrderServiceDao... object created");
}
}
