package ioc;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.rbu.swiggy.dao.OrderServiceDao;
import com.rbu.swiggy.service.OrderService;
import com.rbu.swiggy.web.OrderController;

public class IOCTest1 {
public static void main(String[] args) {
	
	BeanFactory beanFactory=new XmlBeanFactory(new ClassPathResource("resources/spring.xml"));
	
	//archana want to order food
	System.out.println("archana want to order food");
	OrderController o_c=(OrderController)beanFactory.getBean("o-c");
	OrderService o_s=(OrderService)beanFactory.getBean("o-s");
	OrderServiceDao o_d=(OrderServiceDao)beanFactory.getBean("o-d");
	System.out.println("Narender want to order food");
	OrderController o_c1=(OrderController)beanFactory.getBean("o-c");
	OrderService o_s1=(OrderService)beanFactory.getBean("o-s");
	OrderServiceDao o_d1=(OrderServiceDao)beanFactory.getBean("o-d");
	
	System.out.println("Both Controller object same="+(o_c==o_c1));
	
	System.out.println("Both Service object same="+(o_s==o_s1));
	
	System.out.println("Both Dao object same="+(o_d==o_d1));
	
	
	
}
}
