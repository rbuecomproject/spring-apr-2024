package ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.swiggy.dao.OrderServiceDao;
import com.rbu.swiggy.service.OrderService;
import com.rbu.swiggy.web.OrderController;

public class IOCTest2 {
public static void main(String[] args) {
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	//9182662482
	//archana want to order food
	System.out.println("archana want to order food");
	OrderController o_c=(OrderController)ap.getBean("o-c");
	OrderService o_s=(OrderService)ap.getBean("o-s");
	OrderServiceDao o_d=(OrderServiceDao)ap.getBean("o-d");
	System.out.println("Narender want to order food");
	OrderController o_c1=(OrderController)ap.getBean("o-c");
	OrderService o_s1=(OrderService)ap.getBean("o-s");
	OrderServiceDao o_d1=(OrderServiceDao)ap.getBean("o-d");
	
	System.out.println("Both Controller object same="+(o_c==o_c1));
	
	System.out.println("Both Service object same="+(o_s==o_s1));
	
	System.out.println("Both Dao object same="+(o_d==o_d1));
	
	
	
}
}
