public class Test{ 
	
public static void main(String args[]) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
//CDMA
//	Hello obj=new Hello();
//		obj.helloworld();
		
//GSM
	Hello obj1=(Hello)Class.forName(args[0]).newInstance();	
	obj1.helloworld();

}

}