public class Hello{
 
public void helloworld(){
System.out.println("HelloWorld");
}
 
}
 
