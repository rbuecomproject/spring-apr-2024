package beans;

public class A {
	private B b;

	public A(B b) {
		this.b = b;
		System.out.println("A object");
	}

	
}
