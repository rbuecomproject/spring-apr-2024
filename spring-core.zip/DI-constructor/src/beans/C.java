package beans;

public class C {
	private A a ;
	public C(A a ) {
		this.a = a;
		//System.out.println(1 / 0);
		System.out.println("C object");
	}
	
	
}
