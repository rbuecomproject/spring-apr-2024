package beans;

public class B {

	private C c;

	public B(C c) {
		this.c = c;
		System.out.println("B object");
	}

	
}
