package com.rbu.ems.service;

import org.springframework.stereotype.Service;

@Service
public class EmployeService {
	
	public EmployeService() {
	System.out.println("EmployeService object created..");
	}

}
