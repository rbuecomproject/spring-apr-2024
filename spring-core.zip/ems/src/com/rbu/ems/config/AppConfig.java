package com.rbu.ems.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	public AppConfig() {
		System.out.println("AppConfig object created...");
	}
	//we use this class for configuration bean object creation
}
