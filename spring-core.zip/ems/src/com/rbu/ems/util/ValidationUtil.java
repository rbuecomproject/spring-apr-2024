package com.rbu.ems.util;

import org.springframework.stereotype.Component;

@Component
public class ValidationUtil {
	
	public ValidationUtil() {
	System.out.println("ValidationUtil helper object created..");
	}

}
