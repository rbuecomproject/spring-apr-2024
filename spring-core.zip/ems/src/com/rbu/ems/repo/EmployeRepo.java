package com.rbu.ems.repo;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeRepo {
	
	public EmployeRepo() {
	System.out.println("EmployeRepo object created...");
	}

}
