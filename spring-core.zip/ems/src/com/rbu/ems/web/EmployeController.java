package com.rbu.ems.web;

import org.springframework.stereotype.Controller;

@Controller
public class EmployeController {
	
	public EmployeController() {
	System.out.println("EmployeController object created..");
	}

}
