package com.rbu.basics;
	public class HelloWorld{
		
		public HelloWorld() {
		System.out.println("HelloWorld object.....");
		}
		
	
	public void hello(){
		System.out.println("HelloWorld");
	}
	
	}