package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class StudentDao {
	private String driverName;
	private String url;
	private String username;
	private String password;
	public StudentDao() {
	System.out.println("StudentDao object created..");
	}

	public void setDriverName(String driverName) {
		System.out.println("setDriverName.." + driverName);
		this.driverName = driverName;
	}

	public void setUrl(String url) {
		System.out.println("setUrl" + url);
		this.url = url;
	}

	public void setUsername(String username) {
		System.out.println("setUsername" + username);
		this.username = username;
	}

	public void setPassword(String password) {
		System.out.println("setPassword" + password);
		this.password = password;
	}

	public void save(int id, String name, String email, String address) {

		try {
			Class.forName(driverName);
			Connection con = DriverManager.getConnection(url+"?autoReconnect=true&useSSL=false", username, password);
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into RBU_EXPERTS values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
