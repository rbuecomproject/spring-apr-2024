package client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.StudentDao;

public class IOCServer2 {

	public static void main(String[] args) {
		
		ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
		StudentDao dao=ap.getBean(StudentDao.class);
	
		dao.save(1, "pavan", "pavan@gmail.com", "HYD");
		dao.save(2, "ganesh", "ganesh@gmail.com", "HYD");
		dao.save(3, "ravi", "ravi@gmail.com", "HYD");
		dao.save(4, "archana", "archana@gmail.com", "HYD");
		dao.save(5, "abhishake", "abhishake@gmail.com", "HYD");
		dao.save(6, "santosh", "santosh@gmail.com", "HYD");
		dao.save(7, "narender", "narender@gmail.com", "HYD");
		
	
	
	}

}
