package beans;

public class A {
	private B b;
	public A() {
	System.out.println("A object");
	}
	public void setB(B b) {
		System.out.println("setB method");
		this.b = b;
	}

}
