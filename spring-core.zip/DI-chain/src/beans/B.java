package beans;

public class B {

	private C c;

	public B() {
		System.out.println("B object");
	}

	public void setC(C c) {
		System.out.println("setC method");
		this.c = c;
	}

}
