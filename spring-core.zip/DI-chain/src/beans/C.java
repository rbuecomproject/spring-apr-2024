package beans;

public class C {
	private A a ;
	public C() {
		//System.out.println(1 / 0);
		System.out.println("C object");
	}
	
	public void setA(A a) {
	System.out.println("setA method");
		this.a = a;
	}
}
