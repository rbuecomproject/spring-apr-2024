package client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class IOCServer2 {

	public static void main(String[] args) {
		// Adv
		ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
		
		for (int i = 1; i <= 1000; i++) {
			System.out.println("Iterations="+i);
			ap.getBean("o-c");
			ap.getBean("o-s");
			ap.getBean("o-d");
		}

	}

}
