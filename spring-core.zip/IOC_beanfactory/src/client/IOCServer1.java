package client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class IOCServer1 {

	public static void main(String[] args) {
		// LAZY
		BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("resources/spring.xml"));
		
		for (int i = 1; i <= 1000; i++) {
			System.out.println("Iterations="+i);
			beanFactory.getBean("o-c");
			beanFactory.getBean("o-s");
			beanFactory.getBean("o-d");
		}

	}

}
