package com.rbu.swiggy;

public class OrderController {
	public OrderController() {
		System.out.println("OrderController object");
	}

}
