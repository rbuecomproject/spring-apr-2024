package com.rbu.swiggy;

public class OrderService {
	public OrderService() {
		System.out.println("OrderService object");
	}

}
