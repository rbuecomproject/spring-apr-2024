package com.rbu.swiggy;

public class OrderDao {
	public OrderDao() {
		System.out.println("OrderDao object");
	}

}
