package com.rbu.ott;

public class BahubaliMovie {

	public BahubaliMovie() throws InterruptedException {
		System.out.println("Bahubali movie loading.....");
		Thread.sleep(10 * 1000);
		System.out.println("Bahubali movie loaded you can watch.....");
	}

}
