package client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class IOCServer1 {

	public static void main(String[] args) {
		// LAZY
		BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("resources/spring.xml"));
		
		System.out.println("Ravi want to watch Bahubali..");
		beanFactory.getBean("movie");
		System.out.println("Ravi can  watch Bahubali..");
		System.out.println("Ganesh want to watch Bahubali..");
		beanFactory.getBean("movie");
		System.out.println("Ganesh can watch Bahubali..");
		System.out.println("Pavan want to watch Bahubali..");
		beanFactory.getBean("movie");
		System.out.println("Pavan can watch Bahubali..");
		System.out.println("Abhishake want to watch Bahubali..");
		beanFactory.getBean("movie");
		System.out.println("Abhishake can watch Bahubali..");

	}

}
