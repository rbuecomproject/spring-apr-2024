package client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class IOCServer2 {

	public static void main(String[] args) {
		// Adv
		ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
		
		System.out.println("Ravi want to watch Bahubali..");
		ap.getBean("movie");
		System.out.println("Ravi can  watch Bahubali..");
		System.out.println("Ganesh want to watch Bahubali..");
		ap.getBean("movie");
		System.out.println("Ganesh can watch Bahubali..");
		System.out.println("Pavan want to watch Bahubali..");
		ap.getBean("movie");
		System.out.println("Pavan can watch Bahubali..");
		System.out.println("Abhishake want to watch Bahubali..");
		ap.getBean("movie");
		System.out.println("Abhishake can watch Bahubali..");

	}

}
